# rustress

rustress is a tiny module for predicting stress in russian words. Grabbed data from ruwiktionary, parser script, jupyter notebook with model creation are also included in package.

You can predict stress with using predict_stress in predictor.py
